from scapy.all import *

def icmp_echo_request(destination_ip, ttl):
    icmp_packet = IP(dst=destination_ip, ttl=ttl) / ICMP(type=8, code=0)
    
    reply = sr1(icmp_packet)
    
    if reply and ICMP in reply and reply[ICMP].type == 0:  # ICMP Echo Reply
        print("Received ICMP Echo Reply:")
        print(reply.summary())
        print(reply.ttl)
        if reply.ttl == ttl:
            print("packet is not spoofed")
        else:
            print("packet is spoofed")    	
    elif reply and ICMP in reply and reply[ICMP].type == 3:  # Destination Unreachable
        print("Received Destination Unreachable Message:")
        print(reply.summary())
        print("packet is spoofed")
    else:
        print("No ICMP Echo Reply received.")


def tcp_server(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP) as server_socket:
        server_socket.bind((host, port))
        
        print(f"Server listening on {host}:{port}")

        while True:
            data, client_address = server_socket.recvfrom(4096)
            print(f"Received {len(data)} bytes from {client_address}")
            
            ttl = data[8]
            print(f"TTL: {ttl}")
            
            icmp_echo_request(client_address[0], ttl)

if __name__ == "__main__":
    server_host = '10.0.1.2'
    server_port = 1229
    tcp_server(server_host, server_port)
