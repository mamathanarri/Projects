from mininet.net import Mininet
from mininet.node import Node
from mininet.link import Link
from mininet.cli import CLI

def create_topology():
    net = Mininet()

    # Create router
    router = net.addHost('router', cls=Node)

    # Create hosts in network 1
    host1 = net.addHost('host1', ip='10.0.0.2/24')

    # Create hosts in network 2
    host2 = net.addHost('host2', ip='10.0.1.2/24')

    # Add links between router and hosts with IP addresses
    Link(host1, router, intfName2='router-eth0', params2={'ip': '10.0.0.1/24'})
    Link(host2, router, intfName2='router-eth1', params2={'ip': '10.0.1.1/24'})

    # Enable IP forwarding on the router
    router.cmd('sysctl net.ipv4.ip_forward=1')

    # Start network
    net.start()

    # Add routes on host1 and host2 for each other's networks via router
    host1.cmd('ip route add 10.0.1.0/24 via 10.0.0.1')
    host2.cmd('ip route add 10.0.0.0/24 via 10.0.1.1')

    # Test connectivity using pingall
    net.pingAll()

    # Start CLI for interactive testing
    CLI(net)

    # Stop network
    net.stop()

if __name__ == '__main__':
    create_topology()
